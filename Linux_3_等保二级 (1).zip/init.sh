#!/bin/bash
perl_path=$(which perl);
if [[ -z ${perl_path} ]]
then
	echo "perl command not found"
fi
[ $# -ne 0 ] && {
	echo "Usage: sh init.sh ";
	exit 1;
}

# 获取当前路径

pathname=`pwd`

echo "touch /tmp/sangfor_mod_tmp;">/tmp/SF_sxf_tm_sangfor_grub_tmp
echo "chmod 777 /tmp/sangfor_mod_tmp;">>/tmp/SF_sxf_tm_sangfor_grub_tmp
echo "if [ -f \"/etc/grub.conf\" ];then">>/tmp/SF_sxf_tm_sangfor_grub_tmp
echo "    grub_mod=\`ls -l /etc/grub.conf | grep 'l[r-][w-][x-]'\`;">>/tmp/SF_sxf_tm_sangfor_grub_tmp
echo "    if [ -z \"\$grub_mod\" ];then">>/tmp/SF_sxf_tm_sangfor_grub_tmp
echo "        grub_mod=\`ls -l /etc/grub.conf\`;">>/tmp/SF_sxf_tm_sangfor_grub_tmp
echo "        chmod --reference=/etc/grub.conf /tmp/sangfor_mod_tmp;">>/tmp/SF_sxf_tm_sangfor_grub_tmp
echo "    else">>/tmp/SF_sxf_tm_sangfor_grub_tmp
echo "        grub_mod=\`ls -l /boot/grub/grub.conf\`;">>/tmp/SF_sxf_tm_sangfor_grub_tmp
echo "        chmod --reference=/boot/grub/grub.conf /tmp/sangfor_mod_tmp;">>/tmp/SF_sxf_tm_sangfor_grub_tmp
echo "    fi">>/tmp/SF_sxf_tm_sangfor_grub_tmp
echo "elif [ -f \"/boot/grub/grub.conf\" ];then">>/tmp/SF_sxf_tm_sangfor_grub_tmp
echo "    grub_mod=\`ls -l /boot/grub/grub.conf\`;">>/tmp/SF_sxf_tm_sangfor_grub_tmp
echo "    chmod --reference=/boot/grub/grub.conf /tmp/sangfor_mod_tmp;">>/tmp/SF_sxf_tm_sangfor_grub_tmp
echo "elif [ -f \"/etc/lilo.conf\" ];then">>/tmp/SF_sxf_tm_sangfor_grub_tmp
echo "    grub_mod=\`ls -l /etc/lilo.conf\`;">>/tmp/SF_sxf_tm_sangfor_grub_tmp
echo "    chmod --reference=/etc/lilo.conf /tmp/sangfor_mod_tmp;">>/tmp/SF_sxf_tm_sangfor_grub_tmp
echo "fi">>/tmp/SF_sxf_tm_sangfor_grub_tmp
sh /tmp/SF_sxf_tm_sangfor_grub_tmp
# 执行pl脚本
perl "$pathname/main.pl" "$pathname" Linux_3_tag.xml 
